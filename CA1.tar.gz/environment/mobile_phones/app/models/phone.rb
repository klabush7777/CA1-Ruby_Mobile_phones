class Phone < ApplicationRecord
end
